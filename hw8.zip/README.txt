HOMEWORK 8: CITY CHASE


NAME:  Jacob Martin


TIME SPENT ON THIS ASSIGNMENT:  12


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassment, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.



Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



EVADER STRATEGY:
It awards danger values to each of the possible moves checking the surrounding neighbors, their surrounding neighbors, 
and their surrounding neighbors and assigning danger values based on that to give a better indication of where it should go.


PURSUER STRATEGY:
My Pursuer checks all paths to find the fastest path in a depth first search


NEW GRAPH NETWORK FOR EXTRA CREDIT:
Describe your new network and why it makes a fun game.


MISC. COMMENTS TO GRADER:  
Optional, please be concise!
I wrote evader.cpp and pursuer.cpp and they run just fine on my computer and compile/run instantly on my crappy 200$ laptop. But it is killed on the server.






